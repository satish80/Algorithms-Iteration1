﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    public class ReplaceNewLin
    {
        public string[] Replace()
        {
            return DoReplace(new string[]{"a","b","\r\n","c"});
        }

        private string[] DoReplace(string[] arr)
        {
            return null;
        }
    }
}
