﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreeDS
{
    class Program
    {
        static void Main(string[] args)
        {
            //TreeManipulations obj = new TreeManipulations();
            //obj.CalcTreeHeight();
            //obj.DoLevelOrderTraversal();
            //obj.DoPreOrderTraversal();
            //obj.DoReverseLevelOrderTraversal();
            //obj.DoInorderTraversal();
            //obj.DoMirrorTree();
            //obj.DoinorderSpiral();
            //obj.ReverseTree();

            //obj.FindAncestors();
            SearchTree obj = new SearchTree();
            Console.WriteLine(obj.Find(obj.Root,14).value);

            Console.Read();
            //obj.DoPostOrderTraversal();

            #region ArrayToBST
            //int[] arr = new int[] { 1,2,3,4,5};
            //Tree tree = obj.ArrayToBST(arr,0,4);
            #endregion

            #region IsTreeBST
            //obj.IsTreeBST();
            #endregion
        }
    }

    public class Tree
    {
        public Tree Left;
        public Tree Right;
        public int value;
    }
}
