﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Solutions
{
    class Program
    {
        static void Main(string[] args)
        {
            //DLBinaryTree obj = new DLBinaryTree();
            //obj.ConstructTree();

            //Solution2 obj = new Solution2();
            Solution5 obj = new Solution5();
            //Solution1 obj1 = new Solution1();            
            
        }
    }
}
