﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursion
{
    class Program
    {
        static void Main(string[] args)
        {
            //Palindrome obj = new Palindrome();
            //obj.IsPalindrome();
            
            //SumOfDice obj = new SumOfDice();
            //obj.CalculateSumOfDice();

            //Exponentiation obj = new Exponentiation();
            //obj.CalcExponents();

            Robot obj = new Robot();
            obj.RobotProblem();
        }
    }
}
