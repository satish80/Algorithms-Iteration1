﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    public class MedianOfSortedArray
    {
        public void CalcMedian()
        {
            int[] first = new[] { 1,4,7,8};
            int[] second = new[] { 2,3,5,6};

            Console.WriteLine(Median(first,second));
            Console.Read();
        }

        private int Median(int[] first, int[] second)
        {
            int small = 0;
            int big = 0;
            int[] mergedArr = new int[8];
            int idx = 0, count =0;
            bool smallBounds = false, bigBounds = false;
            while (count < 8)
            {
                if (first[small] > second[big] && !bigBounds)
                {   
                    mergedArr[idx++] = second[big];
                    count++;

                    if (big < second.Length - 1)
                        big++;
                    else
                        bigBounds = true;
                }
                else
                {
                    if (small <= first.Length - 1 && !smallBounds )
                    {
                        mergedArr[idx++] = first[small];
                        count++;

                        if (small < first.Length - 1)
                            small++;
                        else
                            smallBounds=true;

                    }                   
                }
                
            }
            return mergedArr[4];
        }
    }
}
